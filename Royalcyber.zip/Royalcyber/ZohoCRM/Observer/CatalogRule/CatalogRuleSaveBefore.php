<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Observer\CatalogRule;

use Royalcyber\ZohoCRM\Observer\AbstractModelSaveBefore;

/**
 * Class CatalogRuleSaveBefore
 * @package Royalcyber\ZohoCRM\Observer\CatalogRule
 */
class CatalogRuleSaveBefore extends AbstractModelSaveBefore
{
}
