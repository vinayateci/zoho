<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Observer\Order;

use Magento\Framework\Event\Observer;
use Magento\Framework\Exception\NoSuchEntityException;
use Royalcyber\ZohoCRM\Model\Source\ZohoModule;
use Royalcyber\ZohoCRM\Observer\AbstractQueue;

/**
 * Class OrderSaveAfter
 * @package Royalcyber\ZohoCRM\Observer\Order
 */
class OrderSaveAfter extends AbstractQueue
{
    /**
     * @param Observer $observer
     *
     * @return AbstractQueue|void
     * @throws NoSuchEntityException
     */
    public function executeAction(Observer $observer)
    {
        $order = $observer->getEvent()->getDataObject();
        if ($order->getZohoEntity() && !$order->hasQueueSave()) {
            $origData = $order->getCustomOrigData();
            $this->helperSync->updateObject($origData, $order, ZohoModule::ORDER);
        } elseif (!$order->isObjectNew() && !$order->hasQueueSave()) {
            $this->helperSync->addObjectToQueue(ZohoModule::ORDER, $order);
        }
    }
}
