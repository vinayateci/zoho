<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Observer;

use Exception;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Royalcyber\ZohoCRM\Helper\Data as HelperData;
use Royalcyber\ZohoCRM\Helper\Sync as HelperSync;
use Royalcyber\ZohoCRM\Model\QueueFactory;
use Psr\Log\LoggerInterface;

/**
 * Class AbstractQueue
 * @package Royalcyber\ZohoCRM\Observer
 */
abstract class AbstractQueue implements ObserverInterface
{
    /**
     * @var QueueFactory
     */
    protected $queueFactory;

    /**
     * @var HelperSync
     */
    protected $helperSync;

    /**
     * @var HelperData
     */
    protected $helperData;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * AbstractQueue constructor.
     *
     * @param QueueFactory $queueFactory
     * @param HelperSync $helperSync
     * @param HelperData $helperData
     * @param LoggerInterface $logger
     */
    public function __construct(
        QueueFactory $queueFactory,
        HelperSync $helperSync,
        HelperData $helperData,
        LoggerInterface $logger
    ) {
        $this->queueFactory = $queueFactory;
        $this->helperSync   = $helperSync;
        $this->helperData   = $helperData;
        $this->logger       = $logger;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        try {
            if ($this->helperData->isEnabled()) {
                $this->executeAction($observer);
            }
        } catch (Exception $e) {
            $this->logger->debug($e->getMessage());
        }
    }

    /**
     * @param Observer $observer
     *
     * @return $this
     */
    public function executeAction(Observer $observer)
    {
        return $this;
    }
}
