<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Controller\Adminhtml\Condition;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Rule\Model\Condition\AbstractCondition;
use Royalcyber\ZohoCRM\Model\Sync;

/**
 * Class NewConditionHtml
 * @package Royalcyber\ZohoCRM\Controller\Adminhtml\Condition
 */
class NewConditionHtml extends Action
{
    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        $id      = $this->getRequest()->getParam('id');
        $typeArr = explode('|', str_replace('-', '/', $this->getRequest()->getParam('type')));
        $type    = $typeArr[0];

        $model = $this->_objectManager->create($type)
            ->setId($id)
            ->setType($type)
            ->setRule($this->_objectManager->create(Sync::class))
            ->setPrefix('conditions');

        if (!empty($typeArr[1])) {
            $model->setAttribute($typeArr[1]);
        }

        if ($model instanceof AbstractCondition) {
            $model->setJsFormObject($this->getRequest()->getParam('form'));
            $html = $model->asHtmlRecursive();
        } else {
            $html = '';
        }

        $this->getResponse()->setBody($html);
    }
}
