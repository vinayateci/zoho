<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Controller\Adminhtml\Product;

use Royalcyber\ZohoCRM\Controller\Adminhtml\AbstractMassAction;
use Royalcyber\ZohoCRM\Model\Source\ZohoModule;

/**
 * Class MassAction
 * @package Royalcyber\ZohoCRM\Controller\Adminhtml\Product
 */
class MassAction extends AbstractMassAction
{
    /**
     * @return string
     */
    public function getType()
    {
        return ZohoModule::PRODUCT;
    }

    /**
     * @return mixed
     */
    public function getCollection()
    {
        return $this->productCollectionFactory->create();
    }

    /**
     * @return string
     */
    public function getRedirectUrl()
    {
        return 'catalog/product';
    }
}
