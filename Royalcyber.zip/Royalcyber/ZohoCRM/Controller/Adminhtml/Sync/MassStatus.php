<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Controller\Adminhtml\Sync;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Royalcyber\ZohoCRM\Controller\Adminhtml\AbstractSync;

/**
 * Class MassStatus
 * @package Royalcyber\ZohoCRM\Controller\Adminhtml\Sync
 */
class MassStatus extends AbstractSync
{
    /**
     * @return ResponseInterface|ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->syncFactory->create()->getCollection());
        $status     = $this->getRequest()->getParam('status');

        $count = 0;
        foreach ($collection->getItems() as $item) {
            $item->setStatus($status)->save();
            $count++;
        }

        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been updated.', $count));

        return $this->_redirect('*/*/');
    }
}
