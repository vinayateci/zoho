<?php

namespace Royalcyber\ZohoCRM\Controller\Index;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Royalcyber\ZohoCRM\Helper\Data as HelperData;
use Magento\Framework\HTTP\Client\Curl;
use Zend_Http_Client;

/**
 * Class Token
 * @package Royalcyber\ZohoCRM\Controller\Index
 */
class Token extends Action
{
    /**
     * @var HelperData
     */
    protected $helperData;
    protected $curl;

    /**
     * @var SessionManagerInterface
     */
    protected $session;

    /**
     * Token constructor.
     *
     * @param Context $context
     * @param HelperData $helperData
     * @param SessionManagerInterface $session
     */
    public function __construct(
        Context $context,
        HelperData $helperData,
        Curl $curl,
        SessionManagerInterface $session
    ) {
        parent::__construct($context);
        $this->helperData = $helperData;
        $this->session    = $session;
        $this->curl = $curl;
    }

    /**
     * @return ResponseInterface|ResultInterface
     */
    public function execute()
    {
        $code = $this->getRequest()->getParam('code');
        if ($code) {
            $clientId = $this->helperData->getClientId();
            if (!$clientId) {
                $this->session->setMpZohoErrorMessage('Please fill Client Id!');

                return $this->_redirect('rczoho/');
            }

            $clientSecret = $this->helperData->getClientSecret();
            if (!$clientSecret) {
                $this->session->setMpZohoErrorMessage('Please fill Client Secret');

                return $this->_redirect('rczoho/');
            }

            $redirectURI = $this->helperData->getRedirectURIs();
            if (!$redirectURI) {
                $this->session->setMpZohoErrorMessage(__('Please fill Authorized redirect URIs'));

                return $this->_redirect('rczoho/');
            }

            $params = [
                'client_id'     => $clientId,
                'client_secret' => $clientSecret,
                'redirect_uri'  => $redirectURI,
                'grant_type'    => 'authorization_code',
                'code'          => $code
            ];

            try {
                // $resp = $this->helperData->requestData(
                //     $this->helperData->getTokenURL(),
                //     Zend_Http_Client::POST,
                //     http_build_query($params),
                //     true
                // );
                $resp = $this->makeACurlRequest($this->helperData->getTokenURL(),$params);
                var_dump($resp);die;

                if ($resp && is_array($resp) && isset($resp['access_token'])) {
                    $this->helperData->saveAPIData($resp);
                    $this->session->setMpZohoSuccessMessage(
                        __('The Access Token has been saved successfully. You can close this window, then clean cache and refresh configuration page.')
                    );
                } else {
                    $this->session->setMpZohoErrorMessage(__('Invalid access token. Please try again!'));
                }
            } catch (Exception $e) {
                $this->session->setMpZohoErrorMessage($e->getMessage());
            }
        } else {
            $this->session->setMpZohoErrorMessage(__('Grant token not found!'));
        }

        return $this->_redirect('rczoho/');
    }
    public function makeACurlRequest($url , $params) {
 
       
       
        //set curl options
       
        try{
        
       // $this->curl->setOption(CURLOPT_HEADER, 0);
        $this->curl->setOption(CURLOPT_TIMEOUT, 60);
        $this->curl->setOption(CURLOPT_RETURNTRANSFER, false);
        //set curl header
      //  $this->curl->addHeader("Content-Type", "application/json");
        //post request with url and data
        $this->curl->post($url, $params);
        //read response
        $response = $this->curl->getBody();
        }catch(Exception $e){
            echo $e->getMessage();die;
        }
        return $response;
      } 
}
