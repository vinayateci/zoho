<?php


namespace Royalcyber\ZohoCRM\Controller\Index;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;

/**
 * Class Index
 * @package Royalcyber\ZohoCRM\Controller\Index
 */
class Index extends Token
{
    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        if ($this->session->getMpZohoErrorMessage()) {
            printf('<b style="color:red">' . $this->session->getMpZohoErrorMessage()->getText() . '</b>');
            $this->session->setMpZohoErrorMessage('');
        }

        if ($this->session->getMpZohoSuccessMessage()) {
            printf('<b style="color:green">' . $this->session->getMpZohoSuccessMessage()->getText() . '</b>');
            $this->session->setMpZohoSuccessMessage('');
        }
    }
}
