<?php

namespace Royalcyber\ZohoCRM\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Sales\Setup\SalesSetup;
use Magento\Sales\Setup\SalesSetupFactory;

/**
 * Class InstallData
 * @package Royalcyber\ZohoCRM\Setup
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var SalesSetupFactory
     */
    protected $salesSetupFactory;

    /**
     * InstallData constructor.
     *
     * @param SalesSetupFactory $salesSetupFactory
     */
    public function __construct(
        SalesSetupFactory $salesSetupFactory
    ) {
        $this->salesSetupFactory = $salesSetupFactory;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        /** @var SalesSetup $salesInstaller */
        $salesInstaller = $this->salesSetupFactory->create(['resourceName' => 'sales_setup', 'setup' => $setup]);
        $salesInstaller->addAttribute(
            'order',
            'zoho_entity',
            [
                'type'    => Table::TYPE_TEXT,
                'visible' => false
            ]
        );
        $salesInstaller->addAttribute(
            'invoice',
            'zoho_entity',
            [
                'type'    => Table::TYPE_TEXT,
                'visible' => false
            ]
        );
        $definition = [
            'type'    => Table::TYPE_TEXT,
            'comment' => 'Zoho Entity',
        ];

        $connection = $installer->getConnection();
        $connection->addColumn($installer->getTable('customer_entity'), 'zoho_entity', $definition);
        $connection->addColumn($installer->getTable('customer_entity'), 'zoho_lead_entity', $definition);
        $connection->addColumn($installer->getTable('customer_entity'), 'zoho_contact_entity', $definition);
        $connection->addColumn($installer->getTable('catalog_product_entity'), 'zoho_entity', $definition);
        $connection->addColumn($installer->getTable('catalogrule'), 'zoho_entity', $definition);
    }
}
