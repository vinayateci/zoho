<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

/**
 * Class UpgradeSchema
 * @package Royalcyber\ZohoCRM\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
        $tableName = $installer->getTable('royalcyber_zoho_queue');
        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $columns = [
                'object_name' => [
                    'type'    => Table::TYPE_TEXT,
                    'length'  => 255,
                    'comment' => 'Object Name',
                    'after'   => 'object'
                ],
                'sync_name' => [
                    'type'    => Table::TYPE_TEXT,
                    'length'  => 255,
                    'comment' => 'Sync Name',
                    'after'   => 'sync_id'
                ]
            ];
            foreach ($columns as $name => $definition) {
                $installer->getConnection()->addColumn($tableName, $name, $definition);
            }
        }

        $installer->endSetup();
    }
}
