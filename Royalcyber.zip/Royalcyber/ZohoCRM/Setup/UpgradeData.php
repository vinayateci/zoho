<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Setup;

use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\UrlInterface;
use Royalcyber\ZohoCRM\Model\QueueFactory;
use Royalcyber\ZohoCRM\Model\SyncFactory;

/**
 * Class UpgradeData
 * @package Royalcyber\ZohoCRM\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var QueueFactory
     */
    protected $queueFactory;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var SyncFactory
     */
    protected $syncFactory;

    /**
     * UpgradeData constructor.
     *
     * @param UrlInterface $urlBuilder
     * @param QueueFactory $queueFactory
     * @param SyncFactory $syncFactory
     */
    public function __construct(
        UrlInterface $urlBuilder,
        QueueFactory $queueFactory,
        SyncFactory $syncFactory
    ) {
        $this->urlBuilder   = $urlBuilder;
        $this->queueFactory = $queueFactory;
        $this->syncFactory  = $syncFactory;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $queueCollection = $this->queueFactory->create()->getCollection();
            if ($queueCollection->getSize()) {
                foreach ($queueCollection as &$queue) {
                    $item = [
                        'magento_object' => $queue->getMagentoObject(),
                        'object'         => $queue->getObject()
                    ];
                    $queueModel  = $this->queueFactory->create();
                    $queueObject = $queueModel->getQueueObject($item, $this->urlBuilder);
                    $syncName    = $this->syncFactory->create()->load($queue->getSyncId())->getName();

                    $queue->setSyncName($syncName);
                    $queue->setObjectName($queueObject['name']);
                }

                $queueCollection->save();
            }
        }
    }
}
