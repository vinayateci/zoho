<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */
namespace Royalcyber\ZohocRM\Block\Adminhtml\Sync\Edit\Tab\Report;

use Royalcyber\ZohoCRM\Block\Adminhtml\Sync\Edit\Tab\QueueReport;
use Royalcyber\ZohoCRM\Model\Source\MagentoObject;

/**
 * Class CatalogRule
 * @package Royalcyber\ZohocRM\Block\Adminhtml\Sync\Edit\Tab\Report
 */
class CatalogRule extends QueueReport
{
    /**
     * @param $fieldset
     */
    public function addExtraFields($fieldset)
    {
        $this->getRequest()->setParam('magento_object', MagentoObject::CATALOG_RULE);
        $this->addZohoEntity($fieldset, $this->getCurrentRule());
    }

    /**
     * @return mixed
     */
    public function getCurrentRule()
    {
        return $this->_coreRegistry->registry('current_promo_catalog_rule');
    }
}
