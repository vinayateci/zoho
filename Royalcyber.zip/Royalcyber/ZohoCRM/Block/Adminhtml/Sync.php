<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */
namespace Royalcyber\ZohoCRM\Block\Adminhtml;

use Magento\Backend\Block\Template;
use Royalcyber\ZohoCRM\Helper\Data;

/**
 * Class Sync
 * @package Royalcyber\ZohoCRM\Block\Adminhtml
 */
class Sync extends Template
{
    /**
     * @return string
     */
    public function getSyncUrl()
    {
        return $this->getUrl('rczoho/queue/sync');
    }

    /**
     * @return string
     */
    public function getEstimateUrl()
    {
        return $this->getUrl('rczoho/queue/estimatesync');
    }

    /**
     * @return string
     */
    public function getOptions()
    {
        $options = [
            'syncUrl'              => $this->getSyncUrl(),
            'estimateUrl'          => $this->getEstimateUrl(),
            'errorMessage'         => __('Synchronize failed.'),
            'estimateErrorMessage' => __('Estimate synchronize failed.'),
            'successMessage'       => __('A total of #1 record(s) have been synchronized. Note that in case there have already 5 times failed, it is unable to synchronize more. Please edit the object data, save and check again. ')
        ];

        return Data::jsonEncode($options);
    }
}
