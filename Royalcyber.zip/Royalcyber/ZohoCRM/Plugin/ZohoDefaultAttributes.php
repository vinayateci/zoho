<?php

namespace Royalcyber\ZohoCRM\Plugin;

use Magento\Eav\Model\Entity\AbstractEntity;

/**
 * Class ZohoDefaultAttributes
 * @package Royalcyber\ZohoCRM\Plugin
 */
class ZohoDefaultAttributes
{
    /**
     * @param AbstractEntity $subject
     * @param array $result
     *
     * @return array
     */
    public function afterGetDefaultAttributes(AbstractEntity $subject, $result)
    {
        $zohoEntity = [
            'zoho_entity',
            'zoho_lead_entity',
            'zoho_contact_entity'
        ];

        return array_merge($result, $zohoEntity);
    }
}
