<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class QueueStatus
 * @package Royalcyber\ZohoCRM\Model\Source
 */
class QueueStatus implements OptionSourceInterface
{
    const PENDING = 1;
    const SUCCESS = 2;
    const ERROR   = 3;

    /**
     * @return array
     */
    public static function getOptionArray()
    {
        return [
            self::PENDING => __('Pending'),
            self::SUCCESS => __('Success'),
            self::ERROR   => __('Error')
        ];
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }
}
