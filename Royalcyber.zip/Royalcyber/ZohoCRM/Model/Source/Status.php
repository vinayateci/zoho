<?php
/**
 * Royalcyber
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the royalcyber.com license that is
 * available through the world-wide-web at this URL:
 * https://www.royalcyber.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Royalcyber
 * @package     Royalcyber_ZohoCRM
 * @copyright   Copyright (c) Royalcyber (https://www.royalcyber.com/)
 * @license     https://www.royalcyber.com/LICENSE.txt
 */

namespace Royalcyber\ZohoCRM\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 * @package Royalcyber\ZohoCRM\Model\Source
 */
class Status implements OptionSourceInterface
{
    const ACTIVE   = 1;
    const INACTIVE = 0;

    /**
     * @return array
     */
    public static function getOptionArray()
    {
        return [
            self::ACTIVE   => __('Active'),
            self::INACTIVE => __('Inactive')
        ];
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }
}
