<?php

namespace Royalcyber\ZohoCRM\Ui\Component\Control;

use Magento\Ui\Component\Control\Action;

/**
 * Class InvoiceAction
 * @package Royalcyber\ZohoCRM\Ui\Component\Control
 */
class InvoiceAction extends Action
{
    /**
     * Prepare
     *
     * @return void
     */
    public function prepare()
    {
        $config  = $this->getConfiguration();
        $context = $this->getContext();

        $config['url'] = $context->getUrl(
            'rczoho/invoice/massAction',
            ['order_id' => $context->getRequestParam('order_id')]
        );
        $this->setData('config', $config);

        parent::prepare();
    }
}
